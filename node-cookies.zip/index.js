const express = require('express');
const app = express();
require('dotenv').config()
const cors = require('cors')
const {v4: uuidv4} = require('uuid');
const crypto = require('crypto');
const fs = require('fs');
const {createInterface} = require('readline');
const {EAuthSessionGuardType, EAuthTokenPlatformType, LoginSession} = require('steam-session');

app.use(express.json());
app.use(cors())

app.use(express.urlencoded({extended: true}));
require('console-stamp')(console, 'yyyy-mm-dd HH:MM:ss.l')

let g_AbortPromptFunc;

let SOCKS_PROXY_URL = 'socks5://127.0.0.1:7890';

app.get('/', async function (req, res) {
    res.json(await success());
})


app.post('/login', async function (req, res) {

    try {

        let accountName = req.body.accountName;
        let password = req.body.password;
        let mobileCode = req.body.code;
        console.log(accountName)
        console.log(password)
        console.log(mobileCode)
        if (accountName === '' || accountName === 'undefined') {
            return res.json(await fail('账号不能为空'));
        }
        if (password === '' || password === 'undefined') {
            return res.json(await fail('密码不能为空'));
        }
        if (mobileCode === '' || mobileCode === 'undefined') {
            return res.json(await fail('手机令牌不能为空'));
        }
        console.log('\nIf you\'re logging into an account using email Steam Guard and you have a machine token, enter it below. Otherwise, just hit enter.');
        // let steamGuardMachineToken = await promptAsync('Machine Token: ');
        let steamGuardMachineToken = mobileCode

        // Create our LoginSession and start a login session using our credentials. This session will be for a client login.
        let session = new LoginSession(EAuthTokenPlatformType.SteamClient);
        let startResult = await session.startWithCredentials({
            accountName,
            password,
            steamGuardMachineToken
        });

        // actionRequired will be true if we need to do something to finish logging in, e.g. supply a code or approve a
        // prompt on our phone.
        if (startResult.actionRequired) {
            console.log('Action is required from you to complete this login');

            // We want to process the non-prompting guard types first, since the last thing we want to do is prompt the
            // user for input. It would be needlessly confusing to prompt for input, then print more text to the console.
            let promptingGuardTypes = [EAuthSessionGuardType.EmailCode, EAuthSessionGuardType.DeviceCode];
            let promptingGuards = startResult.validActions.filter(action => promptingGuardTypes.includes(action.type));
            let nonPromptingGuards = startResult.validActions.filter(action => !promptingGuardTypes.includes(action.type));

            let printGuard = async ({type, detail}) => {
                let code;
                try {
                    switch (type) {
                        case EAuthSessionGuardType.EmailCode:
                            console.log(`A login code has been sent to your email address at ${detail}`);
                            // code = await promptAsync('Code1: ');
                            code = mobileCode;
                            if (code) {
                                await session.submitSteamGuardCode(code);
                            }
                            break;

                        case EAuthSessionGuardType.DeviceCode:
                            console.log('You may confirm this login by providing a Steam Guard Mobile Authenticator code');
                            // code = await promptAsync('Code2: ');
                            code = mobileCode;
                            if (code) {
                                await session.submitSteamGuardCode(code);
                            }
                            break;

                        case EAuthSessionGuardType.EmailConfirmation:
                            console.log('You may confirm this login by email');
                            break;

                        case EAuthSessionGuardType.DeviceConfirmation:
                            console.log('You may confirm this login by responding to the prompt in your Steam mobile app');
                            break;
                    }
                } catch (ex) {
                    res.json(await fail(ex.message));
                }
            };
            nonPromptingGuards.forEach(printGuard);
            promptingGuards.forEach(printGuard);
        }
        session.on('steamGuardMachineToken', () => {
            console.log('\nReceived new Steam Guard machine token');
            console.log(`Machine Token: ${session.steamGuardMachineToken}`);
        });

        await session.on('authenticated', async () => {
            abortPrompt();

            console.log('\nAuthenticated successfully! Printing your tokens now...');
            console.log(`SteamID: ${session.steamID}`);
            console.log(`Account name: ${session.accountName}`);
            console.log(`Access token: ${session.accessToken}`);
            console.log(`Refresh token: ${session.refreshToken}`);

            // We can also get web cookies now that we've negotiated a session
            let webCookies = await session.getWebCookies();
            console.log('Web session cookies:');
            console.log(webCookies);

            let decodedJwt = decodeJwt(session.accessToken);
            console.log(`\nWe logged in using IP ${decodedJwt.ip_subject}`);
            const browserId = uuidv4();
            let cookies = webCookies[0] + '; ' + webCookies[1] + '; browserid=' + browserId + '; Steam_Language=schinese';
            res.json(await success({cookies: cookies, session: webCookies[1]}));
        });
        session.on('timeout', () => {
            abortPrompt();
            console.log('This login attempt has timed out.');
        });
        session.on('error', (err) => {
            abortPrompt();

            // This should ordinarily not happen. This only happens in case there's some kind of unexpected error while
            // polling, e.g. the network connection goes down or Steam chokes on something.
            console.log(`ERROR: This login attempt has failed! ${err.message}`);
        });
    } catch (err) {
        res.json(await fail(err.message));
    }

})


async function abortPrompt() {
    if (!g_AbortPromptFunc) {
        return;
    }

    g_AbortPromptFunc();
    process.stdout.write('\n');
}

async function decodeJwt(jwt) {
    let parts = jwt.split('.');
    if (parts.length != 3) {
        throw new Error('Invalid JWT');
    }

    let standardBase64 = parts[1].replace(/-/g, '+')
        .replace(/_/g, '/');

    return JSON.parse(Buffer.from(standardBase64, 'base64').toString('utf8'));
}


async function promptAsync(question, sensitiveInput = false) {
    return new Promise((resolve) => {
        let rl = createInterface({
            input: process.stdin,
            output: sensitiveInput ? null : process.stdout,
            terminal: true
        });

        g_AbortPromptFunc = () => {
            rl.close();
            resolve('');
        };

        if (sensitiveInput) {
            // We have to write the question manually if we didn't give readline an output stream
            process.stdout.write(question);
        }

        rl.question(question, (result) => {
            if (sensitiveInput) {
                // We have to manually print a newline
                process.stdout.write('\n');
            }

            g_AbortPromptFunc = null;
            rl.close();
            resolve(result);
        });
    });
}

async function success(data = {}) {
    return {code: 200, message: "success", data: data};
}


async function fail(message = 'fail', data = {}) {
    return {code: 500, message: message, data: data};
}

app.listen(9002, '0.0.0.0');
console.info('server start port 9002');
